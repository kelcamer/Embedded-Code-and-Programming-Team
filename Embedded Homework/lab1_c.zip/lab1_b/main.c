//*********************************************************************
// LED turn on to blink the LED on Port 2 of the MSP430FG4618
// experimenter board RAM at 0x1100 - 0x30ff, FLASH at 0x3100 �
// 0xfbff
// Port 2 is used for the LED's Port 2 bit 2 is the green LED,
// Port 2 bit 1 is the yellow LED
// input buttons on port 1 bits SW1 = bit 0 and SW2 = Bit2
// 1 = SW not pressed 0 = pressed
//*********************************************************************
//---------------------------------------------------------------------
// must include the C header to get the predefined variable names
// used by the MSP430FG4618 on the experimenter board
//---------------------------------------------------------------------
#include "msp430fg4618.h"
int main(void)
{
// tell the compiler not to optimize the variable I, otherwise the
// compiler may change how the variable is used
 volatile unsigned int i;
 volatile unsigned int j;
 WDTCTL = WDTPW + WDTHOLD; // Stop watchdog timer so the

 P2DIR |= 0x06; 	// sets both bits as an output

 // go run the program forever
 for (;;){

	 if(P1IN==0x01){		// if the first pin is pressed, turn on the green LED
	 P2OUT =0x02;

	 }

	 if(P1IN==0x02){		// if the second pin is pressed, turn on the yellow LED
		 P2OUT =0x04;

		 }

	 if((P1IN==0x00)){		// if the both pins are pressed, turn on the green and yellow LEDs
		 P2OUT =0x06;

	 }

	 if(P1IN == 0x03){		// turn off if nothing is pressed.
		 P2OUT = 0x00;
	 }



 }
}
