// kelsey cameron

#include "msp430fg4618.h"
#include "stdio.h"
void showEights(void);
void showRightMostTwo_part1(void);
void showLeftMostTwo_part2(void);

// Defined functions for each character, pass in row value.
void zero(int row);
void one(int row);
void two(int row);
void three(int row);
void four(int row);
void five(int row);
void six(int row);
void seven(int row);
void eight(int row);
void nine(int row);
void showA(int row);
void showB(int row);
void showC(int row);
void showD(int row);
void showE(int row);
void showF(int row);
void part3CountToF(void);
void part4Count(void);
void reset(int row);
// 1.0 1.2 SW1 SW2
void Init_LCD(void);
 // setup a pointer to the area of memory of the TMS430 that points to
 // the segments
 // of the softbaugh LCD LCDM3 = the starting address
 // each of the seven segments for each display is store in memory
 // starting at address LCDM3
 // which is the right most seven segment of the LCD

 // The bit order in each byte is
 // dp, E, G, F, D, C, B, A or
 // :, E, G, F, D, C, B, A
 // after the seven segments these memory locations are used to turn on
 // the special characters
 // such as battery status, antenna, f1-f4, etc.
 // there are 7 seven segment displays

unsigned char *LCDSeg = (unsigned char *) &LCDM3;			// a char pointer is used because default for char * is +1 incrementation
 // there are 11 locations that are needed for the softbaugh LCD
 // only 7 used for the seven segment displays

int LCD_SIZE=11;
	int main(void){
			volatile unsigned char a;

				WDTCTL = WDTPW + WDTHOLD; // Stop watchdog timer

				// configure each input and output
					P2DIR |= 0x06;		// 0110
					P1DIR = 0x00;

					Init_LCD();
					//showRightMostTwo_part1();
					//showLeftMostTwo_part2();
					//part3CountToF();
					//part4Count();


			}




//---------------------------------------------------------------------
// Initialize the LCD system
//---------------------------------------------------------------------
void Init_LCD(void){
 // Using the LCD A controller for the MSP430fg4618
 // the pins of the LCD are memory mapped onto the mp430F4xxx
 // memory bus and
 // are accessed via LCDSeg[i] array
 // See page 260 of Davie's text
 // LCD_SIZE-4 only gives the 7 segment displays plus DP, and
 // (colons are the same bit setting)
 // LCD_SIZE-4 only gives the 7 segment displays plus DP, and
 // colons (colons / dp)
 // Right most seven segment display is at LCDSeg[0];
 // Display format
 // AAA
 // F B
 // X F B
 // GGG
 // X E C
 // E C
 // DP DDD

 // bit order
 // dp, E, G, F, D, C, B, A or
 // :, E, G, F, D, C, B, A
int n;
for (n=0;n<LCD_SIZE;n++){
																		 // initialize the segment memory to zero to clear the LCD
																		 // writing a zero in the LCD memory location clears turns
																		 // off the LCD segment
																		 // Including all of the special characters
																		 // This way or
 *(LCDSeg+n) = 0;

 }
																		 // Port 5 ports 5.2-5.4 are connected to com1, com2, com3 of LCD and
																		 // com0 is fixed and already assigned
																		 // Need to assign com1 - com3 to port5
 P5SEL = 0x1C; 		// set port5 to be in charge of the LED														// BIT4 | BIT3 |BIT2 = 1 P5.4, P.3, P5.2 = 1
																		 // Used the internal voltage for the LCD bit 4 = 0 (VLCDEXT=0)
																		 // internal bias voltage set to 1/3 of Vcc, charge pump disabled,
																		 // page 26-25 of MSP430x4xx user manual
 LCDAVCTL0 = 0x00;	// set the voltage of the LEDS to zero
																		 // LCDS28-LCDS0 pins LCDS0 = lsb and LCDS28 = MSB need
																		 // LCDS4 through LCDS24
																		 // from the experimenter board schematic the LCD uses S4-S24,
																		 // S0-S3 are not used here
																		 // Only use up to S24 on the LCD 28-31 not needed.
																		 // Also LCDACTL1 not required since not using S32 - S39
																		 // Davie's book page 260
																		 // page 26-23 of MSP430x4xx user manual
 LCDAPCTL0 = 0x7E;		// set the clock with a divider of 128, scan freq = 256hz
																		 // The LCD uses the ACLK as the master clock as the scan rate for
																		 // the display segments
																		 // The ACLK has been set to 32768 Hz with the external
																		 // 327768 Hz crystal
																		 // Let's use scan frequency of 256 Hz (This is fast enough not
																		 // to see the display flicker)
																		 // or a divisor of 128
																		 // LCDFREQ division(3 bits), LCDMUX (2 bits), LCDSON segments on,
																		 // Not used, LCDON LCD module on
																		 // 011 = freq /128, 11 = 4 mux's needed since the display uses for
																		 // common inputs com0-com3
																		 // need to turn the LCD on LCDON = 1
																		 // LCDSON allows the segments to be blinked good for blinking but
																		 // needs to be on to
																		 // display the LCD segments LCDSON = 1
																		 // Bit pattern required = 0111 1101 = 0x7d
																		 // page 26-22 of MSP430x4xx user manual
 LCDACTL = 0x7d;			 // control signal for 4 multiplexors (2^4 = 16 min you need for 11)
}

void showRightMostTwo_part1(void){
	// At row 0, set the pattern equal to 2
				volatile unsigned int i; 	// volatile to prevent optimization
				LCDSeg[0] |= BIT0;			// 11111111
				LCDSeg[0] |= BIT1;
				LCDSeg[0] |= BIT3;
				LCDSeg[0] |= BIT6;
				LCDSeg[0] |= BIT5;

			}
void showLeftMostTwo_part2(void){
	// At row 6, set the pattern equal to 2
				volatile unsigned int i; 	// volatile to prevent optimization
				LCDSeg[6] |= BIT0;			// 11111111
				LCDSeg[6] |= BIT1;
				LCDSeg[6] |= BIT3;
				LCDSeg[6] |= BIT6;
				LCDSeg[6] |= BIT5;

			}
void showEights(void){
				volatile unsigned int i; 	// volatile to prevent optimization
				for (i=0;i<LCD_SIZE;i++){

					LCDSeg[i]=0xff;	// 1111111
				}


				for (;;){
					P2OUT ^= 0x02; // Toggle P1.0 using exclusive-OR
					i = 20000; // SW Delay
					do i--;
					while (i != 0);
				}
			}
void reset(int row){
	// turns off all bits at a certain row
	LCDSeg[row] = 0x00;


}
void zero(int row){
	// resets, and then makes zero pattern
	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT6;
	LCDSeg[row] |= BIT4;

}
void one(int row){
	// resets, and then makes one pattern

	reset(row);
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;


}
void two(int row){
	// resets, and then makes two pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT6;
	LCDSeg[row] |= BIT5;


}
void three(int row){
	// resets, and then makes three pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT5;


}
void four(int row){
	// resets, and then makes four pattern

	reset(row);
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;

}
void five(int row){
	// resets, and then makes five pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT5;

}
void six(int row){
	// resets, and then makes six pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;

}
void seven(int row){
	// resets, and then makes seven pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;


}
void eight(int row){
	// resets, and then makes eight pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;

}
void nine(int row){
	// resets, and then makes nine pattern

		reset(row);
		LCDSeg[row] |= BIT0;
		LCDSeg[row] |= BIT1;
		LCDSeg[row] |= BIT2;
		LCDSeg[row] |= BIT3;
		LCDSeg[row] |= BIT4;
		LCDSeg[row] |= BIT5;


}
void showA(int row){
	// resets, and then makes A pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;



}
void showB(int row){
	// resets, and then makes b pattern

	reset(row);
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;

}
void showC(int row){
	// resets, and then makes c pattern

	reset(row);
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;


}
void showD(int row){
	// resets, and then makes d pattern

	reset(row);
	LCDSeg[row] |= BIT1;
	LCDSeg[row] |= BIT2;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;


}
void showE(int row){
	// resets, and then makes E pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT3;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;



}
void showF(int row){
	// resets, and then makes F pattern

	reset(row);
	LCDSeg[row] |= BIT0;
	LCDSeg[row] |= BIT4;
	LCDSeg[row] |= BIT5;
	LCDSeg[row] |= BIT6;



}

void part3CountToF(void){
	volatile int i = 0;
	zero(0);

	for(i=0;i<20000;i++);

	one(0);

	for(i=0;i<20000;i++);

	two(0);

	for(i=0;i<20000;i++);

	three(0);

	for(i=0;i<20000;i++);

	four(0);


	for(i=0;i<20000;i++);

	five(0);

	for(i=0;i<20000;i++);

	six(0);

	for(i=0;i<20000;i++);

	seven(0);

	for(i=0;i<20000;i++);

	eight(0);

	for(i=0;i<20000;i++);

	nine(0);

	for(i=0;i<20000;i++);

	showA(0);

	for(i=0;i<20000;i++);

	showB(0);

	for(i=0;i<20000;i++);

	showC(0);


	for(i=0;i<20000;i++);

	showD(0);


	for(i=0;i<20000;i++);

	showE(0);

	for(i=0;i<20000;i++);

	showF(0);

	for(i=0;i<20000;i++);


part3CountToF();
}


void displayBasedOnNum(int row, int num){
	// displays a number based on integer

	if(num == 0){
		zero(row);
	}
	else if(num == 1){
		one(row);
	}
	else if(num == 2){
			two(row);
		}
	else if(num == 3){
			three(row);
		}
	else if(num == 4){
			four(row);
		}
	else if(num == 5){
			five(row);
		}
	else if(num == 6){
			six(row);
		}
	else if(num == 7){
			seven(row);
		}
	else if(num == 8){
			eight(row);
		}
	else if(num == 9){
			nine(row);
		}
	volatile int i = 0;
	for(i=0;i<20000;i++);

}
void part4Count(void){
	int count = 0;
	while(1==1){

		if(P1IN == BIT0){
		// count up
			count++;
		}
		else if(P1IN == BIT1){
		// count down
			count--;
		}

		if(count < 10){
			// reset rows 1 and 2, display the count
			displayBasedOnNum(0, count);
			reset(1);
			reset(2);
		}
		else if(count >= 10 && count < 100){
			// reset row 2, display row 1 and row 0 for tens and ones place
			reset(2);
			displayBasedOnNum(1, (int)(count/10));
			displayBasedOnNum(0, count%10);	//11
		}
		else if(count > 100){		// 317
			int remain100 = count%100;	// 317 %100 = 17	// 317 / 100 = 3		// 317 / 10 = 31  317%10 = 7
			int remain10 = count%10;



			displayBasedOnNum(2, (int)(count/100));
			displayBasedOnNum(1, (int)((count%100) - count%10)/10);
			displayBasedOnNum(0, (int)(count%10));
		}
		// keep counting at max and min
		if(count == 1000){
			count = 0;
		}
		if(count == -1){
			count = 999;
		}


	}




}


